-- MySQL dump 10.13  Distrib 5.5.28, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: findmartial
-- ------------------------------------------------------
-- Server version	5.5.28-0ubuntu0.12.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fm_addserv`
--

DROP TABLE IF EXISTS `fm_addserv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_addserv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_addserv`
--

LOCK TABLES `fm_addserv` WRITE;
/*!40000 ALTER TABLE `fm_addserv` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_addserv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_art`
--

DROP TABLE IF EXISTS `fm_art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_art` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('classic','pervert') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_art`
--

LOCK TABLES `fm_art` WRITE;
/*!40000 ALTER TABLE `fm_art` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_city`
--

DROP TABLE IF EXISTS `fm_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_city`
--

LOCK TABLES `fm_city` WRITE;
/*!40000 ALTER TABLE `fm_city` DISABLE KEYS */;
INSERT INTO `fm_city` VALUES (1,'Пермь');
/*!40000 ALTER TABLE `fm_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_client`
--

DROP TABLE IF EXISTS `fm_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) DEFAULT NULL,
  `check_id` int(11) DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `inn` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mail` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('active','notactive') COLLATE utf8_unicode_ci DEFAULT NULL,
  `money` decimal(10,2) NOT NULL,
  `social` enum('social','municipal') COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimate_value` decimal(10,2) NOT NULL,
  `estimate_number` smallint(6) NOT NULL,
  `news_on` tinyint(1) NOT NULL,
  `is_checked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_21856542E93323CB` (`inn`),
  UNIQUE KEY `UNIQ_2185654213B3DB11` (`master_id`),
  KEY `IDX_21856542709385E7` (`check_id`),
  CONSTRAINT `FK_2185654213B3DB11` FOREIGN KEY (`master_id`) REFERENCES `fm_master` (`id`),
  CONSTRAINT `FK_21856542709385E7` FOREIGN KEY (`check_id`) REFERENCES `fm_client` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_client`
--

LOCK TABLES `fm_client` WRITE;
/*!40000 ALTER TABLE `fm_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_club`
--

DROP TABLE IF EXISTS `fm_club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_club` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `check_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `mail` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `indic_price_min` decimal(10,2) DEFAULT NULL,
  `indic_price_max` decimal(10,2) DEFAULT NULL,
  `age_type` enum('adults','children','common') COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` enum('male','female') COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimate_value` decimal(10,2) NOT NULL,
  `estimate_number` smallint(6) NOT NULL,
  `one_training_free` tinyint(1) DEFAULT NULL,
  `photo` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_checked` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E289055119EB6921` (`client_id`),
  KEY `IDX_E28905518BAC62AF` (`city_id`),
  KEY `IDX_E2890551709385E7` (`check_id`),
  CONSTRAINT `FK_E289055119EB6921` FOREIGN KEY (`client_id`) REFERENCES `fm_client` (`id`),
  CONSTRAINT `FK_E2890551709385E7` FOREIGN KEY (`check_id`) REFERENCES `fm_club` (`id`),
  CONSTRAINT `FK_E28905518BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `fm_city` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_club`
--

LOCK TABLES `fm_club` WRITE;
/*!40000 ALTER TABLE `fm_club` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_club` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_club_art`
--

DROP TABLE IF EXISTS `fm_club_art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_club_art` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `club_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6061C5D461190A32` (`club_id`),
  KEY `IDX_6061C5D48C25E51A` (`art_id`),
  CONSTRAINT `FK_6061C5D461190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`),
  CONSTRAINT `FK_6061C5D48C25E51A` FOREIGN KEY (`art_id`) REFERENCES `fm_art` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_club_art`
--

LOCK TABLES `fm_club_art` WRITE;
/*!40000 ALTER TABLE `fm_club_art` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_club_art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_club_level`
--

DROP TABLE IF EXISTS `fm_club_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_club_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `club_id` int(11) DEFAULT NULL,
  `value` enum('noob','beginner','hardcore','nightmare') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_25D789D261190A32` (`club_id`),
  CONSTRAINT `FK_25D789D261190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_club_level`
--

LOCK TABLES `fm_club_level` WRITE;
/*!40000 ALTER TABLE `fm_club_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_club_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_club_servise`
--

DROP TABLE IF EXISTS `fm_club_servise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_club_servise` (
  `club_id` int(11) NOT NULL,
  `addserv_id` int(11) NOT NULL,
  PRIMARY KEY (`club_id`,`addserv_id`),
  KEY `IDX_7F0864AE61190A32` (`club_id`),
  KEY `IDX_7F0864AE597E7D43` (`addserv_id`),
  CONSTRAINT `FK_7F0864AE597E7D43` FOREIGN KEY (`addserv_id`) REFERENCES `fm_addserv` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_7F0864AE61190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_club_servise`
--

LOCK TABLES `fm_club_servise` WRITE;
/*!40000 ALTER TABLE `fm_club_servise` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_club_servise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_club_type`
--

DROP TABLE IF EXISTS `fm_club_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_club_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `club_id` int(11) DEFAULT NULL,
  `value` enum('self','group','minigroup','individ') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_61FA801A61190A32` (`club_id`),
  CONSTRAINT `FK_61FA801A61190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_club_type`
--

LOCK TABLES `fm_club_type` WRITE;
/*!40000 ALTER TABLE `fm_club_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_club_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_group`
--

DROP TABLE IF EXISTS `fm_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CFFD528A5E237E06` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_group`
--

LOCK TABLES `fm_group` WRITE;
/*!40000 ALTER TABLE `fm_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_master`
--

DROP TABLE IF EXISTS `fm_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id` int(11) DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `family` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `patronym` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hightlights` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` enum('male','female') COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slave` tinyint(1) DEFAULT NULL,
  `estimate_value` decimal(10,2) NOT NULL,
  `estimate_number` smallint(6) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `is_checked` tinyint(1) NOT NULL,
  `experience_full` int(11) DEFAULT NULL,
  `training_exp_full` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CBC8C2C1709385E7` (`check_id`),
  CONSTRAINT `FK_CBC8C2C1709385E7` FOREIGN KEY (`check_id`) REFERENCES `fm_master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_master`
--

LOCK TABLES `fm_master` WRITE;
/*!40000 ALTER TABLE `fm_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_master_art`
--

DROP TABLE IF EXISTS `fm_master_art`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_master_art` (
  `master_id` int(11) NOT NULL,
  `art_id` int(11) NOT NULL,
  `expirience` smallint(6) DEFAULT NULL,
  `training_exp` smallint(6) DEFAULT NULL,
  `is_checked` tinyint(1) NOT NULL,
  `master_approve` tinyint(1) NOT NULL,
  `club_approve` tinyint(1) NOT NULL,
  PRIMARY KEY (`master_id`,`art_id`),
  KEY `IDX_E211429D13B3DB11` (`master_id`),
  KEY `IDX_E211429D8C25E51A` (`art_id`),
  CONSTRAINT `FK_E211429D13B3DB11` FOREIGN KEY (`master_id`) REFERENCES `fm_master` (`id`),
  CONSTRAINT `FK_E211429D8C25E51A` FOREIGN KEY (`art_id`) REFERENCES `fm_art` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_master_art`
--

LOCK TABLES `fm_master_art` WRITE;
/*!40000 ALTER TABLE `fm_master_art` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_master_art` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_master_client`
--

DROP TABLE IF EXISTS `fm_master_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_master_client` (
  `master_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `master_approve` tinyint(1) NOT NULL,
  `client_approve` tinyint(1) NOT NULL,
  PRIMARY KEY (`master_id`,`client_id`),
  KEY `IDX_7014024B13B3DB11` (`master_id`),
  KEY `IDX_7014024B19EB6921` (`client_id`),
  CONSTRAINT `FK_7014024B13B3DB11` FOREIGN KEY (`master_id`) REFERENCES `fm_master` (`id`),
  CONSTRAINT `FK_7014024B19EB6921` FOREIGN KEY (`client_id`) REFERENCES `fm_client` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_master_client`
--

LOCK TABLES `fm_master_client` WRITE;
/*!40000 ALTER TABLE `fm_master_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_master_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_master_club`
--

DROP TABLE IF EXISTS `fm_master_club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_master_club` (
  `master_id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `master_approve` tinyint(1) NOT NULL,
  `club_approve` tinyint(1) NOT NULL,
  PRIMARY KEY (`master_id`,`club_id`),
  KEY `IDX_5A4866F213B3DB11` (`master_id`),
  KEY `IDX_5A4866F261190A32` (`club_id`),
  CONSTRAINT `FK_5A4866F213B3DB11` FOREIGN KEY (`master_id`) REFERENCES `fm_master` (`id`),
  CONSTRAINT `FK_5A4866F261190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_master_club`
--

LOCK TABLES `fm_master_club` WRITE;
/*!40000 ALTER TABLE `fm_master_club` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_master_club` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_price`
--

DROP TABLE IF EXISTS `fm_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_typical` tinyint(1) DEFAULT NULL,
  `type` enum('once','counter','timer') COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_count` smallint(6) DEFAULT NULL,
  `number_cost` decimal(10,2) DEFAULT NULL,
  `period_count` smallint(6) DEFAULT NULL,
  `period_cost` decimal(10,2) DEFAULT NULL,
  `value` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_price`
--

LOCK TABLES `fm_price` WRITE;
/*!40000 ALTER TABLE `fm_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_schedule`
--

DROP TABLE IF EXISTS `fm_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `training_id` int(11) DEFAULT NULL,
  `weekday` enum('mon','tue','wen','thr','fri','sat','sun') COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_650E2262BEFD98D1` (`training_id`),
  CONSTRAINT `FK_650E2262BEFD98D1` FOREIGN KEY (`training_id`) REFERENCES `fm_training` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_schedule`
--

LOCK TABLES `fm_schedule` WRITE;
/*!40000 ALTER TABLE `fm_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_training`
--

DROP TABLE IF EXISTS `fm_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price_id` int(11) DEFAULT NULL,
  `art_id` int(11) DEFAULT NULL,
  `check_id` int(11) DEFAULT NULL,
  `master_id` int(11) DEFAULT NULL,
  `club_id` int(11) DEFAULT NULL,
  `type` enum('self','group','minigroup','individ') COLLATE utf8_unicode_ci DEFAULT NULL,
  `age_low` smallint(6) DEFAULT NULL,
  `age_max` smallint(6) DEFAULT NULL,
  `is_checked` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EA24B916D614C7E7` (`price_id`),
  KEY `IDX_EA24B9168C25E51A` (`art_id`),
  KEY `IDX_EA24B916709385E7` (`check_id`),
  KEY `IDX_EA24B91613B3DB11` (`master_id`),
  KEY `IDX_EA24B91661190A32` (`club_id`),
  CONSTRAINT `FK_EA24B91613B3DB11` FOREIGN KEY (`master_id`) REFERENCES `fm_master` (`id`),
  CONSTRAINT `FK_EA24B91661190A32` FOREIGN KEY (`club_id`) REFERENCES `fm_club` (`id`),
  CONSTRAINT `FK_EA24B916709385E7` FOREIGN KEY (`check_id`) REFERENCES `fm_training` (`id`),
  CONSTRAINT `FK_EA24B9168C25E51A` FOREIGN KEY (`art_id`) REFERENCES `fm_art` (`id`),
  CONSTRAINT `FK_EA24B916D614C7E7` FOREIGN KEY (`price_id`) REFERENCES `fm_price` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_training`
--

LOCK TABLES `fm_training` WRITE;
/*!40000 ALTER TABLE `fm_training` DISABLE KEYS */;
/*!40000 ALTER TABLE `fm_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fm_user`
--

DROP TABLE IF EXISTS `fm_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fm_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `family` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `estimate_value` decimal(10,2) DEFAULT NULL,
  `estimate_count` smallint(6) DEFAULT NULL,
  `comments_number` smallint(6) DEFAULT NULL,
  `about` longtext COLLATE utf8_unicode_ci,
  `avatar` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorised_comments` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D7F4EB6A92FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_D7F4EB6AA0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_D7F4EB6A19EB6921` (`client_id`),
  CONSTRAINT `FK_D7F4EB6A19EB6921` FOREIGN KEY (`client_id`) REFERENCES `fm_client` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fm_user`
--

LOCK TABLES `fm_user` WRITE;
/*!40000 ALTER TABLE `fm_user` DISABLE KEYS */;
INSERT INTO `fm_user` VALUES (2,NULL,'admin','admin','admin@test.ru','admin@test.ru',0,'46tschxa6e2oo0cc8ww8go040sksk8c','admin',NULL,0,0,NULL,NULL,NULL,'a:1:{i:0;s:10:\"ROLE_ADMIN\";}',0,NULL,'admin','admin',NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `fm_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-18  6:39:36
